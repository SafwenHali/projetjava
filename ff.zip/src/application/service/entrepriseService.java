package application.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import application.connexion;
import application.entities.employe;
import application.entities.salarie;
import application.entities.vendeur;

public class entrepriseService {

	public void createEmploye(employe e) {
		try {
			if (e.getAnneRecruit() > 2005)
				e.setSalaire(280);
			else if (e.getAnneRecruit() <= 2005)
				e.setSalaire(400);

			String req = "insert into salarie values(" + e.getMatricule() + ",'" + e.getNom() + "', '" + e.getEmail()
					+ "', " + e.getAnneRecruit() + ", " + e.getSalaire() + ", 'employe');";
			Statement stmt = connexion.getConx().createStatement();
			if (stmt.executeUpdate(req) == 1) {
				System.out.println("Insertion a Salarie avec success!");
			}
			String req2 = "insert into employee values(" + e.getMatricule() + "," + e.getHsupp() + "," + e.getPhsupp()
					+ ")";
			if (stmt.executeUpdate(req2) == 1) {
				System.out.println("Insertion a Employee avec success!");
			}
		} catch (SQLException ex) {
			System.out.println("Erreur SQL" + ex);
		}
	}

	public void createVendeur(vendeur v) {
		try {
			if (v.getAnneRecruit() > 2005)
				v.setSalaire(280);
			else if (v.getAnneRecruit() <= 2005)
				v.setSalaire(400);

			String req = "insert into salarie values(" + v.getMatricule() + ",'" + v.getNom() + "', '" + v.getEmail()
					+ "', " + v.getAnneRecruit() + ", " + v.getSalaire() + ", 'vendeur');";
			Statement stmt = connexion.getConx().createStatement();
			if (stmt.executeUpdate(req) == 1) {
				System.out.println("Insertion a Salarie avec success!");
			}
			String req2 = "insert into vendeur values (" + v.getMatricule() + "," + v.getVente() + ","
					+ v.getPourcentage() + ")";
			if (stmt.executeUpdate(req2) == 1) {
				System.out.println("Insertion a Vendeur avec success!");
			}
		} catch (SQLException ex) {
			System.out.println("Erreur SQL" + ex);
		}
	}

	public List<salarie> listerEmployee() {
		List<salarie> emps = new ArrayList<>();
		try {
			String reqE = "SELECT s.matricule, nom, email, role, anneRecruit, (salaire + HSupp * PHSupp) as salaireTot  from salarie s, employee e where s.matricule = e.Matricule;";
			Statement stmt = connexion.getConx().createStatement();
			ResultSet rsE = stmt.executeQuery(reqE);

			while (rsE.next()) {
				emps.add(new salarie(rsE.getInt(1), rsE.getString(2), rsE.getString(3), rsE.getDouble(5),
						rsE.getDouble(6), rsE.getString(4)));
			}
			return emps;

		} catch (SQLException ex) {
			System.out.println("Erreur SQL" + ex);
		}
		return null;
	}

	public List<salarie> listerVendeur() {
		List<salarie> vdrs = new ArrayList<>();
		try {
			String reqV = "SELECT s.matricule, nom, email, anneRecruit, (salaire + vente * pourcentage) as salaireTot, role from salarie s, vendeur v where s.matricule = v.Matricule;";
			Statement stmt = connexion.getConx().createStatement();
			ResultSet rsE = stmt.executeQuery(reqV);
			while (rsE.next()) {
				vdrs.add(new salarie(rsE.getInt(1), rsE.getString(2), rsE.getString(3), rsE.getDouble(4),
						rsE.getDouble(5), rsE.getString(6)));
			}
			return vdrs;
		} catch (SQLException ex) {
			System.out.println("Erreur SQL" + ex);
		}
		return null;

	}

	public void deleteSalarie(int id) {
		try {
			String req = "delete from salarie where matricule=" + id;
			Statement stmt = connexion.getConx().createStatement();
			if (stmt.executeUpdate(req) == 1) {
				System.out.println("Delete avec succes");
			}
		} catch (SQLException ex) {
			System.out.println("SQL ERROR" + ex);
		}
	}

	public void updateEmploye(employe e) {
		try {
			String req = "update salarie set matricule=" + e.getMatricule() + ",nom='" + e.getNom() + "', email='"
					+ e.getEmail() + "', anneRecruit=" + e.getAnneRecruit() + " where matricule=" + e.getMatricule();
			Statement stmt = connexion.getConx().createStatement();
			if (stmt.executeUpdate(req) == 1) {
				System.out.println("Salarie Updated");
			}
			String req1 = "update employee set  Matricule=" + e.getMatricule() + ", PHSupp=" + e.getPhsupp() + ",HSupp="
					+ e.getHsupp() + " where Matricule=" + e.getMatricule();

			if (stmt.executeUpdate(req1) == 1) {
				System.out.println("Employe Updated");
			}
		} catch (SQLException ex) {
			System.out.println("SQL ERROR" + ex);
		}

	}

	public void updateVendeur(vendeur v) {
		try {
			String req = "update salarie set matricule=" + v.getMatricule() + ",nom='" + v.getNom() + "', email='"
					+ v.getEmail() + "', anneRecruit=" + v.getAnneRecruit() + " where matricule=" + v.getMatricule();
			Statement stmt = connexion.getConx().createStatement();
			if (stmt.executeUpdate(req) == 1) {
				System.out.println("Salarie Updated");
			}
			String req1 = "update vendeur set  Matricule=" + v.getMatricule() + ", Pourcentage=" + v.getPourcentage()
					+ ",Vente=" + v.getVente() + " where Matricule=" + v.getMatricule();

			if (stmt.executeUpdate(req1) == 1) {
				System.out.println("Vendeur Updated");
			}
		} catch (SQLException ex) {
			System.out.println("SQL ERROR" + ex);
		}
	}

	public salarie getSalarie(int id) {
		try {
			String reqRole = "Select role from salarie where matricule = " + id;
			Statement stmt = connexion.getConx().createStatement();
			ResultSet rs = stmt.executeQuery(reqRole);
			if (rs.next()) {
				if (rs.getString(1).equals("vendeur")) {
					String req = "Select s.matricule, nom, email, Role, anneRecruit,(salaire + Vente * Pourcentage) from salarie s, vendeur v where s.matricule = v.Matricule and s.matricule = "
							+ id;
					ResultSet rsv = stmt.executeQuery(req);
					if (rsv.next())
						return new salarie(rsv.getInt(1), rsv.getString(2), rsv.getString(3),
								rsv.getDouble(5), rsv.getDouble(6), rsv.getString(4));
				} else {
					String req = "Select s.matricule, nom, email, Role, anneRecruit,(salaire + HSupp * PHSupp) from salarie s, employee v where s.matricule = v.Matricule and s.matricule = "
							+ id;
					ResultSet rsv = stmt.executeQuery(req);
					if (rsv.next())
						return new salarie(rsv.getInt(1), rsv.getString(2), rsv.getString(3),
								rsv.getDouble(5), rsv.getDouble(6), rsv.getString(4));
				}
			}
		} catch (SQLException ex) {
			System.out.println("SQL ERROR" + ex);
		}
		return null;
	}
	public static void main(String Args[]) {
		entrepriseService ES = new entrepriseService();

		//vendeur v = new vendeur(102, "Ali 2", "ali@email.com", 2002, 400, 10, .5);

		//ES.updateVendeur(v);
		System.out.println(ES.getSalarie(111).toString());
	}

}
