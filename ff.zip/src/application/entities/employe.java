package application.entities;

public class employe extends salarie {
private double hsupp;
private double phsupp;


public employe(int matricule, String nom, String email, double anneRecruit, double salaire, String cat, double hsupp,
		double phsupp) {
	super(matricule, nom, email, anneRecruit, salaire, cat);
	this.hsupp = hsupp;
	this.phsupp = phsupp;
}
public double getHsupp() {
	return hsupp;
}
public void setHsupp(double hsupp) {
	this.hsupp = hsupp;
}
public double getPhsupp() {
	return phsupp;
}
public void setPhsupp(double phsupp) {
	this.phsupp = phsupp;
}

}

