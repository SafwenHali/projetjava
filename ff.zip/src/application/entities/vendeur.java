package application.entities;

public class vendeur extends salarie {
private double vente;
private double pourcentage;

public vendeur(int matricule, String nom, String email, double anneRecruit, double salaire, String cat, double vente,
		double pourcentage) {
	super(matricule, nom, email, anneRecruit, salaire, cat);
	this.vente = vente;
	this.pourcentage = pourcentage;
}

public double getVente() {
	return vente;
}
public void setVente(double vente) {
	this.vente = vente;
}
public double getPourcentage() {
	return pourcentage;
}
public void setPourcentage(double pourcentage) {
	this.pourcentage = pourcentage;
}

}
