package application.entities;

import java.util.HashMap;

public class entreprise {
private String nomentreprise;
private HashMap<Integer, salarie> salaries;

public entreprise(String nomentreprise) {
	super();
	this.nomentreprise = nomentreprise;
}
public String getNomentreprise() {
	return nomentreprise;
}
public void setNomentreprise(String nomentreprise) {
	this.nomentreprise = nomentreprise;
}
public HashMap<Integer, salarie> getSalaries() {
	return salaries;
}
public void setSalaries(HashMap<Integer, salarie> salaries) {
	this.salaries = salaries;
}

}
