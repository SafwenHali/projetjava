package application;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import application.entities.employe;
import application.entities.salarie;
import application.entities.vendeur;
import application.service.entrepriseService;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class controllerApp implements Initializable {

	@FXML
	private RadioButton rbEmployee;
	@FXML
	private RadioButton rbVendeur;

	@FXML
	private TextField tfMatricule;
	@FXML
	private TextField tfNom;
	@FXML
	private TextField tfEmail;
	@FXML
	private TextField tfAnneRecruit;
	@FXML
	private TextField tfHeurs;
	@FXML
	private TextField tfPourcentage;
	@FXML
	private TextField tfVente;
	@FXML
	private TextField tfTaux;

	@FXML
	private Button addBtn;
	@FXML
	private Button deleteBtn;
	@FXML
	private Button editBtn;
	@FXML
	private Button exportBtn;
	@FXML
	private Button catBtn;
	@FXML
	private Button dateBtn;
	@FXML
	private Button validModifBtn;
	@FXML
	private TableView<salarie> table;
	@FXML
	private TableColumn<salarie, Integer> matriculeCol;
	@FXML
	private TableColumn<salarie, String> nameCol;
	@FXML
	private TableColumn<salarie, String> emailCol;
	@FXML
	private TableColumn<salarie, String> catCol;
	@FXML
	private TableColumn<salarie, Double> salaireCol;

	@Override

	public void initialize(URL arg0, ResourceBundle arg1) {
		matriculeCol.setCellValueFactory(new PropertyValueFactory<>("Matricule"));
		nameCol.setCellValueFactory(new PropertyValueFactory<>("Nom"));
		emailCol.setCellValueFactory(new PropertyValueFactory<>("Email"));
		catCol.setCellValueFactory(new PropertyValueFactory<>("Cat"));
		salaireCol.setCellValueFactory(new PropertyValueFactory<>("Salaire"));
		entrepriseService e = new entrepriseService();
		List<salarie> x1 = e.listerEmployee();

		List<salarie> x2 = e.listerVendeur();
		table.getItems().addAll(x1);

		table.getItems().addAll(x2);
	}

	public void ajoutSalarie() {
		entrepriseService e = new entrepriseService();
		if (rbEmployee.isSelected()) {
			employe emp = new employe(Integer.parseInt(tfMatricule.getText()), tfNom.getText(), tfEmail.getText(),
					Double.parseDouble(tfAnneRecruit.getText()), 0.1, "employee", Double.parseDouble(tfHeurs.getText()),
					Double.parseDouble(tfTaux.getText()));

			e.createEmploye(emp);
			salarie s = e.getSalarie(Integer.parseInt(tfMatricule.getText()));
			boolean x = table.getItems().add(s);
			rbEmployee.setSelected(false);
		} else if (rbVendeur.isSelected()) {
			vendeur v = new vendeur(Integer.parseInt(tfMatricule.getText()), tfNom.getText(), tfEmail.getText(),
					Double.parseDouble(tfAnneRecruit.getText()), 0.1, "vendeur", Double.parseDouble(tfVente.getText()),
					Double.parseDouble(tfPourcentage.getText()));

			e.createVendeur(v);
			salarie s = e.getSalarie(Integer.parseInt(tfMatricule.getText()));
			boolean x = table.getItems().add(s);
			rbVendeur.setSelected(false);
		}
		
	}
	public void deleteselected() {
		entrepriseService e = new entrepriseService();
		e.deleteSalarie(table.getSelectionModel().getSelectedItem().getMatricule());
		table.getItems().remove(table.getSelectionModel().getSelectedItem());
	}
	
	public void listercategorie() {
		entrepriseService e = new entrepriseService();
		table.getItems().clear();
		if (rbEmployee.isSelected()) {
			List<salarie> x1 = e.listerEmployee();

			
			table.getItems().addAll(x1);

			
		} else if (rbVendeur.isSelected()) {
			

			List<salarie> x2 = e.listerVendeur();
		

			table.getItems().addAll(x2);
		}
	}
}
